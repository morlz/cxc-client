<template>
<div class="">

</div>
</template>

<script>
export default {
	components: {

	},
	props: {

	},
	data () {
		return {

		}
	},
	watch: {

	},
	computed: {

	},
	methods: {

	},
	created () {

	},
	mounted () {

	}
}
</script>

<style lang="stylus">
</style>
