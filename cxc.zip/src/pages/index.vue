<template>
<q-page>
	<table class="Table">
		<tr>
			<td></td>
			<td v-for="day, index in $moment().daysInMonth()">
				<div class="Table__value">
					{{ day }}
				</div>
			</td>
		</tr>

		<tr v-for="man, index in mans">
			<td>
				<div class="">
					{{ man }}
				</div>
			</td>

			<td v-for="day, index in $moment().daysInMonth()">
				<div class="Table__value">
					<table-cell value=""/>
					<!--<q-select value="" :options="hours"/>-->
				</div>
			</td>
		</tr>
	</table>
</q-page>
</template>

<script>
import TableCell from '@/components/TableCell'

export default {
	components: {
		TableCell
	},
	data () {
		return {
			mans: Array.apply(null, { length: 30 }).map(el => (Math.random() * 100).toFixed(2)),
			hours: Array.apply(null, { length: 9 }).map((el, index) => ({
				label: ((index - 4) * 2).toFixed(),
				value: ((index - 4) * 2)
			}))
		}
	},
	watch: {

	},
	computed: {

	},
	methods: {

	},
	created () {

	},
	mounted () {

	}
}
</script>

<style lang="stylus">
.Table
	width 100%
	border-collapse collapse
	tr:hover > td
		background rgba(0, 0, 0, .10)
	td
		margin 0
		padding 0

	&__value
		min-height 30px
		min-width 30px
		border 1px solid #eee
		&:hover
			border 1px solid #e9e
</style>
