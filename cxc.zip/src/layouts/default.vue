<template>
<q-layout view="lHh Lpr lFf">
	<q-layout-header>
		<q-toolbar color="primary" :glossy="$q.theme === 'mat'" :inverted="$q.theme === 'ios'">
			<q-btn flat dense round @click="leftDrawerOpen = !leftDrawerOpen" aria-label="Menu">
				<q-icon name="menu" />
			</q-btn>

			<q-toolbar-title>
				Ведомости
				<div slot="subtitle">{{ $moment().format('DD-MM-YYYY') }} - {{ $moment().add(1, 'day').format('DD-MM-YYYY') }}</div>
			</q-toolbar-title>
		</q-toolbar>
	</q-layout-header>

	<q-layout-drawer v-model="leftDrawerOpen" :content-class="$q.theme === 'mat' ? 'bg-grey-2' : null">
		<q-list no-border link inset-delimiter>
			<q-list-header>Ведомости по группам</q-list-header>
			<q-item v-for="group, index in groups" :key="index">
				<q-item-main :label="group.name" :sublabel="group.dateText" />
			</q-item>
		</q-list>
	</q-layout-drawer>

	<q-page-container>
		<router-view />
	</q-page-container>
</q-layout>
</template>

<script>
import {
	openURL
} from 'quasar'

export default {
	name: 'LayoutDefault',
	data() {
		return {
			leftDrawerOpen: this.$q.platform.is.desktop,
			groups: [
				{ name: '1514-2', dateText: `${this.$moment().format('DD-MM-YYYY')} - ${this.$moment().add(1, 'day').format('DD-MM-YYYY')}` }
			]
		}
	},
	methods: {
		openURL
	}
}
</script>

<style>
</style>
