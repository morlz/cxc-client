<template>
<div class="TableCell">
	{{ value }}
</div>
</template>

<script>
export default {
	components: {

	},
	props: {
		value: Number
	},
	data () {
		return {

		}
	},
	watch: {

	},
	computed: {

	},
	methods: {

	},
	created () {

	},
	mounted () {

	}
}
</script>

<style lang="stylus">
</style>
